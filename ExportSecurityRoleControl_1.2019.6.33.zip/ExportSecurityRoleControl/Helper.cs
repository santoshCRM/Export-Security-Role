﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using System.IO;
using System.Xml;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Net;
namespace ExportSecurityRole
{
    public static class Helper
    {
        #region variable used
        private static List<privilegeSet> _privilage;
        internal static List<privilegeSet> Privilage
        {
            get { return Helper._privilage; }
            set { Helper._privilage = value; }
        }
        private static List<misprivilegeSet> _misprivilage;
        internal static List<misprivilegeSet> misPrivilage
        {
            get { return Helper._misprivilage; }
            set { Helper._misprivilage = value; }
        }
        private static List<SecurityRole> _securityRoles;
        internal static List<SecurityRole> SecurityRoles
        {
            get { return Helper._securityRoles; }
            set { Helper._securityRoles = value; }
        }
        private static IOrganizationService _serviceProxy;
        public static IOrganizationService ServiceProxy
        {
            get { return Helper._serviceProxy; }
            set { Helper._serviceProxy = value; }
        }
        private static string _OrganizationUri;
        public static string OrganizationUri
        {
            get { return Helper._OrganizationUri; }
            set { Helper._OrganizationUri = value; }
        }
        private static ClientCredentials _Credentials = null;
        public static ClientCredentials Credentials
        {
            get { return Helper._Credentials; }
            set { Helper._Credentials = value; }
        }

        #endregion

        internal static void createConn()
        {

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            _serviceProxy = new OrganizationServiceProxy(new Uri(OrganizationUri), null, Credentials, null);

        }
        internal static string CreateXml(string xml, string cookie, int page, int count)
        {
            StringReader stringReader = new StringReader(xml);
            XmlTextReader reader = new XmlTextReader(stringReader);

            // Load document
            XmlDocument doc = new XmlDocument();
            doc.Load(reader);

            return CreateXml(doc, cookie, page, count);
        }
        internal static string CreateXml(XmlDocument doc, string cookie, int page, int count)
        {
            XmlAttributeCollection attrs = doc.DocumentElement.Attributes;

            if (cookie != null)
            {
                XmlAttribute pagingAttr = doc.CreateAttribute("paging-cookie");
                pagingAttr.Value = cookie;
                attrs.Append(pagingAttr);
            }

            XmlAttribute pageAttr = doc.CreateAttribute("page");
            pageAttr.Value = System.Convert.ToString(page);
            attrs.Append(pageAttr);

            XmlAttribute countAttr = doc.CreateAttribute("count");
            countAttr.Value = System.Convert.ToString(count);
            attrs.Append(countAttr);

            StringBuilder sb = new StringBuilder(1024);
            StringWriter stringWriter = new StringWriter(sb);

            XmlTextWriter writer = new XmlTextWriter(stringWriter);
            doc.WriteTo(writer);
            writer.Close();

            return sb.ToString();
        }
        internal static List<SecurityRole> getSecurityRole()
        {
            EntityCollection returnCollection;
            List<SecurityRole> accessRoles = new List<SecurityRole>();
            int fetchCount = 5000;// Initialize the page number.
            int pageNumber = 1;// Initialize the number of records.
            string pagingCookie = null;
            string fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>"
  + "<entity name='role'>"
    + "<attribute name='name' />"
    + "<attribute name='businessunitid' />"
    + "<attribute name='roleid' />"
    + "<order attribute='name' descending='false' />"
        + "<filter type='and'>"
          + "<condition attribute='businessunitid' operator='eq-businessid'  />"
        + "</filter>"
  + "</entity>"
+ "</fetch>";
            while (true)
            {
                // Build fetchXml string with the placeholders.
                string xml = CreateXml(fetchXML, pagingCookie, pageNumber, fetchCount);

                // Excute the fetch query and get the xml result.
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(xml)
                };

                returnCollection = ((RetrieveMultipleResponse)_serviceProxy.Execute(fetchRequest1)).EntityCollection;
                foreach (Entity ent in returnCollection.Entities)
                {
                    SecurityRole SecurityRole = new SecurityRole();

                    SecurityRole.Name = ent.Attributes["name"].ToString();
                    SecurityRole.BusinessUnit = (EntityReference)ent.Attributes["businessunitid"];
                    SecurityRole.RoldId = ent.Id;
                    accessRoles.Add(SecurityRole);
                }

                // Check for morerecords, if it returns 1.
                if (returnCollection.MoreRecords)
                {
                    // Increment the page number to retrieve the next page.
                    pageNumber++;
                    // Set the paging cookie to the paging cookie returned from current results.                            
                    pagingCookie = returnCollection.PagingCookie;
                }
                else
                {
                    // If no more records in the result nodes, exit the loop.
                    break;
                }
            }


            return accessRoles;
        }
        internal static void RolePrivileges(SecurityRole entity)
        {
            EntityCollection returnCollection;
            Privilage = new List<privilegeSet>();
            misPrivilage = new List<misprivilegeSet>();
            int fetchCount = 5000;// Initialize the page number.
            int pageNumber = 1;// Initialize the number of records.
            string pagingCookie = null;
            string fetchXML = "<fetch returntotalrecordcount='true' >" +
"  <entity name='roleprivileges' >" +
"    <attribute name='privilegedepthmask' />" +
"    <link-entity name='role' from='roleid' to='roleid' alias='role' >" +
"      <attribute name='name' />" +
"      <filter>" +
"        <condition attribute='name' operator='eq' value='" + entity.Name + "' />" +
"      </filter>" +
"    </link-entity>" +
"    <link-entity name='privilegeobjecttypecodes' from='privilegeid' to='privilegeid' alias='objecttype' >" +
"      <attribute name='objecttypecode' />" +
"    </link-entity>" +
"    <link-entity name='privilege' from='privilegeid' to='privilegeid'  alias='privilege' >" +
"      <attribute name='accessright' />" +
"      <attribute name='name' />" +
"    </link-entity>" +
"  </entity>" +
"</fetch>";
            while (true)
            {
                // Build fetchXml string with the placeholders.
                string xml = CreateXml(fetchXML, pagingCookie, pageNumber, fetchCount);

                // Excute the fetch query and get the xml result.
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(xml)
                };

                returnCollection = ((RetrieveMultipleResponse)_serviceProxy.Execute(fetchRequest1)).EntityCollection;


                // Check for morerecords, if it returns 1.
                if (returnCollection.MoreRecords)
                {
                    // Increment the page number to retrieve the next page.
                    pageNumber++;
                    // Set the paging cookie to the paging cookie returned from current results.                            
                    pagingCookie = returnCollection.PagingCookie;
                }
                else
                {
                    // If no more records in the result nodes, exit the loop.
                    break;
                }
            }
            privilegeSet pri = null;

            bool check = true;
            foreach (Entity ent in returnCollection.Entities)
            {
                if (((AliasedValue)ent.Attributes["objecttype.objecttypecode"]).Value.ToString() == "none")
                {
                    misprivilegeSet mispri = new misprivilegeSet(((AliasedValue)ent.Attributes["privilege.name"]).Value.ToString());
                    misPrivilage.Add(mispri);
                }
                else
                {
                    var item = Privilage.FirstOrDefault(i => i.LogicalName == ((AliasedValue)ent.Attributes["objecttype.objecttypecode"]).Value.ToString());

                    if (item != null)
                    {
                        pri = (privilegeSet)item; check = false;
                    }
                    else
                    {
                        pri = new privilegeSet(((AliasedValue)ent.Attributes["objecttype.objecttypecode"]).Value.ToString());
                        check = true;
                    }


                    #region Switch Case
                    switch (((AliasedValue)ent.Attributes["privilege.accessright"]).Value.ToString())
                    {
                        case "1"://READ
                            {
                                if (ent.Attributes["privilegedepthmask"].ToString() == "1")//User
                                {
                                    pri.Read = Properties.Resources.user;
                                    pri.Read.Tag = "User";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "2")//Business Unit
                                {
                                    pri.Read = Properties.Resources.BU;
                                    pri.Read.Tag = "Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "4")//Parent: Child Business Unit
                                {
                                    pri.Read = Properties.Resources.P_BU;
                                    pri.Read.Tag = "Parent: Child Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "8")//Organisation
                                {
                                    pri.Read = Properties.Resources.organization;
                                    pri.Read.Tag = "Organization";
                                }
                                break;
                            }
                        case "2"://WRITE
                            {
                                if (ent.Attributes["privilegedepthmask"].ToString() == "1")//User
                                {
                                    pri.Write = Properties.Resources.user;
                                    pri.Write.Tag = "User";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "2")//Business Unit
                                {
                                    pri.Write = Properties.Resources.BU;
                                    pri.Write.Tag = "Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "4")//Parent: Child Business Unit
                                {
                                    pri.Write = Properties.Resources.P_BU;
                                    pri.Write.Tag = "Parent: Child Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "8")//Organisation
                                {
                                    pri.Write = Properties.Resources.organization;
                                    pri.Write.Tag = "Organization";
                                }
                                break;
                            }
                        case "4"://APPEND
                            {
                                if (ent.Attributes["privilegedepthmask"].ToString() == "1")//User
                                {
                                    pri.Append = Properties.Resources.user;
                                    pri.Append.Tag = "User";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "2")//Business Unit
                                {
                                    pri.Append = Properties.Resources.BU;
                                    pri.Append.Tag = "Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "4")//Parent: Child Business Unit
                                {
                                    pri.Append = Properties.Resources.P_BU;
                                    pri.Append.Tag = "Parent: Child Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "8")//Organisation
                                {
                                    pri.Append = Properties.Resources.organization;
                                    pri.Append.Tag = "Organization";
                                }
                                break;
                            }
                        case "16"://APPENDTO
                            {
                                if (ent.Attributes["privilegedepthmask"].ToString() == "1")//User
                                {
                                    pri.AppendTo = Properties.Resources.user;
                                    pri.AppendTo.Tag = "User";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "2")//Business Unit
                                {
                                    pri.AppendTo = Properties.Resources.BU;
                                    pri.AppendTo.Tag = "Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "4")//Parent: Child Business Unit
                                {
                                    pri.AppendTo = Properties.Resources.P_BU;
                                    pri.AppendTo.Tag = "Parent: Child Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "8")//Organisation
                                {
                                    pri.AppendTo = Properties.Resources.organization;
                                    pri.AppendTo.Tag = "Organization";
                                }
                                break;
                            }
                        case "32"://CREATE
                            {
                                if (ent.Attributes["privilegedepthmask"].ToString() == "1")//User
                                {
                                    pri.Create = Properties.Resources.user;
                                    pri.Create.Tag = "User";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "2")//Business Unit
                                {
                                    pri.Create = Properties.Resources.BU;
                                    pri.Create.Tag = "Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "4")//Parent: Child Business Unit
                                {
                                    pri.Create = Properties.Resources.P_BU;
                                    pri.Create.Tag = "Parent: Child Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "8")//Organisation
                                {
                                    pri.Create = Properties.Resources.organization;
                                    pri.Create.Tag = "Organization";
                                }
                                break;
                            }
                        case "65536"://DELETE
                            {
                                if (ent.Attributes["privilegedepthmask"].ToString() == "1")//User
                                {
                                    pri.Delete = Properties.Resources.user;
                                    pri.Delete.Tag = "User";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "2")//Business Unit
                                {
                                    pri.Delete = Properties.Resources.BU;
                                    pri.Delete.Tag = "Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "4")//Parent: Child Business Unit
                                {
                                    pri.Delete = Properties.Resources.P_BU;
                                    pri.Read.Tag = "Parent: Child Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "8")//Organisation
                                {
                                    pri.Delete = Properties.Resources.organization;
                                    pri.Delete.Tag = "Organization";
                                }
                                break;
                            }
                        case "262144"://SHARE
                            {
                                if (ent.Attributes["privilegedepthmask"].ToString() == "1")//User
                                {
                                    pri.Share = Properties.Resources.user;
                                    pri.Share.Tag = "User";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "2")//Business Unit
                                {
                                    pri.Share = Properties.Resources.BU;
                                    pri.Share.Tag = "Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "4")//Parent: Child Business Unit
                                {
                                    pri.Share = Properties.Resources.P_BU;
                                    pri.Share.Tag = "Parent: Child Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "8")//Organisation
                                {
                                    pri.Share = Properties.Resources.organization;
                                    pri.Share.Tag = "Organization";
                                }
                                break;
                            }
                        case "524288"://ASSIGN
                            {
                                if (ent.Attributes["privilegedepthmask"].ToString() == "1")//User
                                {
                                    pri.Assign = Properties.Resources.user;
                                    pri.Assign.Tag = "User";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "2")//Business Unit
                                {
                                    pri.Assign = Properties.Resources.BU;
                                    pri.Assign.Tag = "Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "4")//Parent: Child Business Unit
                                {
                                    pri.Assign = Properties.Resources.P_BU;
                                    pri.Assign.Tag = "Parent: Child Business Unit";
                                }
                                if (ent.Attributes["privilegedepthmask"].ToString() == "8")//Organisation
                                {
                                    pri.Assign = Properties.Resources.organization;
                                    pri.Assign.Tag = "Organization";
                                }
                                break;
                            }
                    }
                    #endregion
                    if (check)
                        Privilage.Add(pri);
                }
            }
        }
    }
}

