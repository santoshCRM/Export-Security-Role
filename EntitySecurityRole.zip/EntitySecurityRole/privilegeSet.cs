﻿using Microsoft.Crm.Sdk.Messages;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitySecurityRole
{
   internal class privilegeSet
    {
        
        private string _roleName;
        public string RoleName
        {
            get { return _roleName; }
            set { _roleName = value; }
        }
        private Image _create;

        public Image Create
        {
            get { return _create; }
            set { _create = value; }
        }
        private Image _read;

        public Image Read
        {
            get { return _read; }
            set { _read = value; }
        }
        private Image _write;

        public Image Write
        {
            get { return _write; }
            set { _write = value; }
        }
        private Image _delete;

        public Image Delete
        {
            get { return _delete; }
            set { _delete = value; }
        }
        private Image _append;

        public Image Append
        {
            get { return _append; }
            set { _append = value; }
        }
        private Image _appendTo;

        public Image AppendTo
        {
            get { return _appendTo; }
            set { _appendTo = value; }
        }
        private Image _assign;

        public Image Assign
        {
            get { return _assign; }
            set { _assign = value; }
        }
        private Image _share;


        public Image Share
        {
            get { return _share; }
            set { _share = value; }
        }

       

       public privilegeSet(string name)
        {
            RoleName = name;
            Create = Properties.Resources.none;
            Read = Properties.Resources.none;
            Write = Properties.Resources.none;
            Delete = Properties.Resources.none;
            Append =  Properties.Resources.none;
            AppendTo = Properties.Resources.none;
            Assign = Properties.Resources.none;
            Share = Properties.Resources.none;
        }

       


    }
}
