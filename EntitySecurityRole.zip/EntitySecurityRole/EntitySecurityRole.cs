﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using XrmToolBox.Extensibility;

namespace EntitySecurityRole
{
    public partial class EntitySecurityRole : PluginControlBase
    {
        public EntitySecurityRole()
        {
            InitializeComponent();
           
        }

        private void btn_retEntity_Click(object sender, EventArgs e)
        {
            Helper.createConn(Service);
            if (Service != null)
            {
                WorkAsync(new WorkAsyncInfo
           {
               Message = "Retrieveing entities and security roles...",
               Work = (bw, m) =>
               {

                   //Set entity drop down
                   drp_entities.DataSource = null;
                   drp_entities.Items.Clear();
                   List<MyEntity> MyEntitys = Helper.getEntities();
                   MyEntitys.Sort((p, q) => p.DisplayName.CompareTo(q.DisplayName));
                   MyEntity Select = new MyEntity();
                   Select.DisplayName = "--Select--";
                   Select.EntityId = Guid.Empty;
                   MyEntitys.Insert(0, Select);
                   drp_entities.DataSource = MyEntitys;
                   drp_entities.DisplayMember = "DisplayName";
                   drp_entities.ValueMember = "EntityId";
                    
                   //Set business unit drop down
                   drp_BU.DataSource = null;
                   drp_BU.Items.Clear();
                   List<MyBusinessUnit> MyBus = Helper.getBUs();
                   MyBus.Sort((p, q) => p.DisplayName.CompareTo(q.DisplayName));
                   MyBusinessUnit Selectbu = new MyBusinessUnit();
                   Selectbu.DisplayName = "--Select--";
                   Selectbu.BuID = Guid.Empty;
                   MyBus.Insert(0, Selectbu);
                   drp_BU.DataSource = MyBus;
                   drp_BU.DisplayMember = "DisplayName";
                   drp_BU.ValueMember = "BuID";

                   //Set security role list
                   lstview_sRole.DataSource = null;
                   List<SecurityRole> userRoles = Helper.getSecurityRole();
                   Helper.SecurityRoles = userRoles;
                   lstview_sRole.DataSource = Helper.SecurityRoles;
                   lstview_sRole.DisplayMember = "Name";
                   lstview_sRole.ValueMember = "RoldId";
               },
               PostWorkCallBack = m =>
               {
                   if (m.Error == null)
                   {

                   }
                   else
                   {
                       MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                       MessageBoxIcon.Error);
                   }
               }
           });
            }
           



        }
        private void drp_entities_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool flag = this.drp_entities.SelectedIndex > 0;
            if (flag)
            {
                WorkAsync(new WorkAsyncInfo
         {
             Message = "Retrieveing security roles for " + ((MyEntity)drp_entities.SelectedItem).DisplayName,
             Work = (bw, m) =>
             {
                 grdview_user.DataSource = null;
                 MyEntity entity = (MyEntity)drp_entities.SelectedItem;
                 Helper.RolePrivileges(entity);

                 grdview_user.DataSource = Helper.Privilage;
                 grdview_user.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                 grdview_user.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                 grdview_user.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                 grdview_user.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                 grdview_user.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                 grdview_user.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                 grdview_user.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                 grdview_user.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
             },
             PostWorkCallBack = m =>
             {
                 if (m.Error == null)
                 {

                 }
                 else
                 {
                     MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                     MessageBoxIcon.Error);
                 }
             }
         });
            }


        }
      
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text))
                grdview_user.DataSource = Helper.Privilage.Where(x => x.RoleName.ToLower().Contains(textBox1.Text.ToLower())).ToList();
            else
                grdview_user.DataSource = Helper.Privilage;
        }

        private void lstview_sRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool flag = this.lstview_sRole.SelectedIndex > 0;
            bool flag2 = this.drp_BU.SelectedIndex > 0;
           
            if (flag && flag2)
            {
                SecurityRole SecurityRole = (SecurityRole)lstview_sRole.SelectedItem;
                List<Team> userTeams = Helper.getTeambySecurityRole(SecurityRole.Name, ((MyBusinessUnit)(drp_BU.SelectedItem)).DisplayName);
                Helper.Teams = userTeams;
                lstbox_Teams.DataSource = Helper.Teams;
                lstbox_Teams.DisplayMember = "Name";
                lstbox_Teams.ValueMember = "TeamId";

                List<systemUser> SystemUsers = Helper.getUserbySecurityRole(SecurityRole.Name, ((MyBusinessUnit)(drp_BU.SelectedItem)).DisplayName);
                Helper.SystemUser = SystemUsers;
                lstbox_users.DataSource = Helper.SystemUser;
                lstbox_users.DisplayMember = "FullName";
                lstbox_users.ValueMember = "SystemUserID";


            }
        }

        private void drp_BU_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstview_sRole_SelectedIndexChanged(sender, e);
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            base.CloseTool();
        }


    }
}
