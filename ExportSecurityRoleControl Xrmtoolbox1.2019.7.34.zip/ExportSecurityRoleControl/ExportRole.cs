﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using XrmToolBox.Extensibility;
using McTools.Xrm.Connection;
using Microsoft.Office.Interop.Excel;

namespace ExportSecurityRole
{
    public partial class ExportRole : PluginControlBase
    {
        private Settings mySettings;
        public ExportRole()
        {
            InitializeComponent();
        }

        #region retrieve Role click
        private void btn_retRole_Click(object sender, EventArgs e)
        {
            //Set Role drop down
            drp_roles.DataSource = null;
            drp_roles.Items.Clear();
            List<SecurityRole> MyEntitys = Helper.getSecurityRole();
            MyEntitys.Sort((p, q) => p.Name.CompareTo(q.Name));

            SecurityRole Select = new SecurityRole();
            Select.Name = "--Select--";
            Select.RoldId = Guid.Empty;
            MyEntitys.Insert(0, Select);
            drp_roles.DataSource = MyEntitys;
            drp_roles.DisplayMember = "Name";
            drp_roles.ValueMember = "RoldId";

            grdview_role.DataSource = null;
            grdview_misRole.DataSource = null;


        }
        #endregion

        private void drp_entities_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool flag = this.drp_roles.SelectedIndex > 0;
            if (flag)
            {
                grdview_role.DataSource = null;
                SecurityRole entity = (SecurityRole)drp_roles.SelectedItem;
                Helper.RolePrivileges(entity);

                grdview_role.DataSource = Helper.Privilage;
                grdview_role.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                grdview_role.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                grdview_role.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                grdview_role.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                grdview_role.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                grdview_role.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                grdview_role.Columns[6].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                grdview_role.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                grdview_role.Columns[8].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                //Miscellaneous Privileges
                grdview_misRole.DataSource = null;

                grdview_misRole.DataSource = Helper.misPrivilage;
                grdview_misRole.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                grdview_misRole.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            }


        }

       

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text))
                grdview_role.DataSource = Helper.Privilage.Where(x => x.LogicalName.ToLower().Contains(textBox1.Text.ToLower())).ToList();
            else
                grdview_role.DataSource = Helper.Privilage;
        }



        private void btn_Export_Click(object sender, EventArgs e)
        {
            try
            {
                if (grdview_role.Rows.Count > 1)
                {
                    _Application app = new Microsoft.Office.Interop.Excel.Application();
                    // creating new WorkBook within Excel application  
                    _Workbook workbook = app.Workbooks.Add(Type.Missing);
                    // creating new Excelsheet in workbook  
                    _Worksheet worksheet = null;
                    // see the excel sheet behind the program  
                    app.Visible = true;
                    // get the reference of first sheet. By default its name is Sheet1.  
                    // store its reference to worksheet  

                    worksheet = workbook.Sheets["Sheet1"];
                    worksheet = workbook.ActiveSheet;
                    // changing the name of active sheet  
                    worksheet.Name = "Entity Privileges";
                    // storing header part in Excel  
                    for (int i = 1; i < grdview_role.Columns.Count + 1; i++)
                    {
                        worksheet.Cells[1, i] = grdview_role.Columns[i - 1].HeaderText;

                    }
                    //Header Style
                    Style HeaderStyle = workbook.Styles.Add("HeaderStyle");
                    HeaderStyle.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                    HeaderStyle.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Green);
                    Range HrangeStyles = app.get_Range("A1", "I1");
                    HrangeStyles.Style = "HeaderStyle";
                    //Cell Style
                    Style CellStyle = workbook.Styles.Add("CellStyle");
                    CellStyle.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                    CellStyle.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DimGray);
                    Range CrangeStyles = app.get_Range("A2", "A" + (grdview_role.Rows.Count));
                    CrangeStyles.Style = "CellStyle";

                    // storing Each row and column value to excel sheet  
                    for (int i = 0; i < grdview_role.Rows.Count ; i++)
                    {
                        for (int j = 0; j < grdview_role.Columns.Count; j++)
                        {
                            if (grdview_role.Rows[i].Cells[j].ValueType.Name.ToString() == "String")
                            {
                                worksheet.Cells[i + 2, j + 1] = grdview_role.Rows[i].Cells[j].Value.ToString();
                            }
                            else
                            {
                                if (((Image)grdview_role.Rows[i].Cells[j].Value).Tag != null)
                                    worksheet.Cells[i + 2, j + 1] = ((Image)grdview_role.Rows[i].Cells[j].Value).Tag.ToString();
                            }

                        }
                    }
                    if (grdview_misRole.Rows.Count > 1)
                    {
                        _Worksheet newWorksheet;
                        newWorksheet = workbook.Worksheets.Add();

                        newWorksheet = workbook.ActiveSheet;
                        newWorksheet.Name = "Miscellaneous Privileges";
                        // storing header part in Excel  
                        for (int i = 1; i < grdview_misRole.Columns.Count + 1; i++)
                        {
                            newWorksheet.Cells[1, i] = grdview_misRole.Columns[i - 1].HeaderText;

                        }


                        // storing Each row and column value to excel sheet  
                        for (int i = 0; i < grdview_misRole.Rows.Count; i++)
                        {
                            for (int j = 0; j < grdview_misRole.Columns.Count; j++)
                            {
                                if (grdview_misRole.Rows[i].Cells[j].ValueType.Name.ToString() == "String")
                                {
                                    newWorksheet.Cells[i + 2, j + 1] = grdview_misRole.Rows[i].Cells[j].Value.ToString();
                                }
                                else
                                {
                                    if (((Image)grdview_misRole.Rows[i].Cells[j].Value).Tag != null)
                                        newWorksheet.Cells[i + 2, j + 1] = ((Image)grdview_misRole.Rows[i].Cells[j].Value).Tag.ToString();
                                }

                            }
                        }
                        newWorksheet.Columns.AutoFit();
                    }
                    worksheet.Columns.AutoFit();

                    // save the application 
                    workbook.SaveAs(saveExcel(((SecurityRole)drp_roles.SelectedItem).Name), Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    // Exit from the application  
                    app.Quit();
                }
            }
            catch (Exception ex)
            {
                LogError("Error occured while exporting security role, Close all excel sheets and try again", ex);
                OpenLogFile();
            }
        }

        internal object saveExcel(string excelname)
        {

            SaveFileDialog sfd = new SaveFileDialog();// Create save the Excel
            sfd.Filter = "Text File|*.xlsx";// filters for text files only
            sfd.DefaultExt = "xlsx";
            sfd.AddExtension = true;
            sfd.FileName = excelname+ ".xlsx";
            sfd.Title = "Save Excel File";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                return sfd.FileName;
            }
            else
            {
                return null;
            }
        }

       
        public override void UpdateConnection(IOrganizationService newService, ConnectionDetail detail, string actionName, object parameter)
        {
            base.UpdateConnection(newService, detail, actionName, parameter);

            if (mySettings != null && detail != null)
            {
                mySettings.LastUsedOrganizationWebappUrl = detail.WebApplicationUrl;
                LogInfo("Connection has changed to: {0}", detail.WebApplicationUrl);
            }
        }

        private void ExportRole_Load(object sender, EventArgs e)
        {
            Helper.ServiceProxy= base.Service;
            if (!SettingsManager.Instance.TryLoad(GetType(), out mySettings))
            {
                mySettings = new Settings();

                LogWarning("Settings not found => a new settings file has been created!");
            }
            else
            {
                LogInfo("Settings found and loaded");
            }
        }
    }
}
