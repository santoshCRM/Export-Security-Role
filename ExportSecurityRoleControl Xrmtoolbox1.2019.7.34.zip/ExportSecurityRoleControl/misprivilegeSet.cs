﻿using System.Drawing;

namespace ExportSecurityRole
{
   internal class misprivilegeSet
    {
        
        
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        private Image _role;

        public Image Role
        {
            get { return _role; }
            set { _role = value; }
        }


        public misprivilegeSet(string name)
        {
            Name = name;
            Role = Properties.Resources.organization;
            Role.Tag = "Organization";
           
           
        }

       


    }
}
