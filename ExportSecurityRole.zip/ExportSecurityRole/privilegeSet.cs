﻿using Microsoft.Crm.Sdk.Messages;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExportSecurityRole
{
   internal class privilegeSet
    {
        
        
        private string _logicalname;

        public string LogicalName
        {
            get { return _logicalname; }
            set { _logicalname = value; }
        }
        private Image _create;

        public Image Create
        {
            get { return _create; }
            set { _create = value; }
        }
        private Image _read;

        public Image Read
        {
            get { return _read; }
            set { _read = value; }
        }
        private Image _write;

        public Image Write
        {
            get { return _write; }
            set { _write = value; }
        }
        private Image _delete;

        public Image Delete
        {
            get { return _delete; }
            set { _delete = value; }
        }
        private Image _append;

        public Image Append
        {
            get { return _append; }
            set { _append = value; }
        }
        private Image _appendTo;

        public Image AppendTo
        {
            get { return _appendTo; }
            set { _appendTo = value; }
        }
        private Image _assign;

        public Image Assign
        {
            get { return _assign; }
            set { _assign = value; }
        }
        private Image _share;


        public Image Share
        {
            get { return _share; }
            set { _share = value; }
        }
       
       public privilegeSet(string name)
        {
            LogicalName = name;
            Create = Properties.Resources.none;
            Create.Tag = "None";
            Read = Properties.Resources.none;
            Read.Tag = "None";
            Write = Properties.Resources.none;
            Write.Tag = "None";
            Delete = Properties.Resources.none;
            Delete.Tag = "None";
            Append =  Properties.Resources.none;
            Append.Tag = "None";
            AppendTo = Properties.Resources.none;
            AppendTo.Tag = "None";
            Assign = Properties.Resources.none;
            Assign.Tag = "None";
            Share = Properties.Resources.none;
            Share.Tag = "None";
           
        }

       


    }
}
